# Journal

A newsletter theme for [Ghost](http://github.com/tryghost/ghost/). This is the latest development version of Journal, and only used for theme installation! If you're looking to contribute, head over to the main repository [here](https://github.com/TryGhost/Themes). If you're just looking to download the latest release, download the theme [here](https://github.com/TryGhost/Journal/archive/refs/heads/main.zip).

# Copyright & License

Copyright (c) 2013-2021 Ghost Foundation - Released under the [MIT license](LICENSE).
